import pygame
import random
x=pygame.init()
# print(x)

# random number
a=random.randint(30,600)
b=random.randint(30,300)


# color code
red = (255,0,0)
black= (0,0,0)
white= (255,255,255)


#display settings
game_window = pygame.display.set_mode((900,500))
pygame.display.set_caption("himanshu's snake game")
pygame.display.update()


#variable for games
exit_game = False
game_over = False
snake_x = 155
snake_y = 255
snake_size = 10
fps = 30
velo_x=0
velo_y=0
food_x=a
food_y=b
score=0
food_size = 15

# clock
clock = pygame.time.Clock()

# creating a loop
while not exit_game:
    for event in pygame.event.get():
      if event.type ==pygame.QUIT:
          exit_game = True

      if event.type == pygame.KEYDOWN:

          if event.key == pygame.K_RIGHT:
            # snake_x = snake_x +10
            velo_x = 5
            velo_y = 0
          if event.key == pygame.K_LEFT:
            # snake_x = snake_x -10
            velo_x = -5
            velo_y =0

          if event.key == pygame.K_UP:
            # snake_y = snake_y -10
            velo_y = -5
            velo_x=0
          if event.key == pygame.K_DOWN:
            # snake_y = snake_y +10
            velo_y = 5
            velo_x = 0


    snake_x = snake_x + velo_x
    snake_y = snake_y + velo_y

    if (food_x-2<= snake_x <= food_x+2 and food_y-2 <= snake_y <=food_y+2):
          # snake_size = snake_size +10
          food_x = random.randint(30,600)
          food_y = random.randint(30,300)
          score =score+1
          print(score)



    game_window.fill(white)
    pygame.draw.rect(game_window,black ,[snake_x ,snake_y,snake_size,snake_size])
    pygame.draw.rect(game_window, red, [food_x, food_y, food_size,food_size])
    pygame.display.update()

    clock.tick(fps)




pygame.quit()
quit()
